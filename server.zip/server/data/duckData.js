const ducks = [
    { id: 1, name: "Yellow Duck", color: "yellow", imageUrl: "images/duck1.webp" },
    { id: 2, name: "Yellow Duck with Glasses", color: "yellow", imageUrl: "images/duck2.jpg" },
    { id: 3, name: "Shark Duck", color: "blue", imageUrl: "images/duck3.webp" },
    { id: 4, name: "Elvis Duck", color: "blue", imageUrl: "images/duck4.webp" }
];

export default ducks;
